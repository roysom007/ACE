let activeTabs = {};
chrome.browserAction.onClicked.addListener(function(tab) {
    console.log(tab);
    activeTabs[tab.id] = {tab: tab};
        let ev = {
            name: 'boot',
            data: {tabId: tab.id}
        };
        chrome.tabs.sendMessage(tab.id, ev);
});

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
    if (msg.text == "what is my tab_id?") {
        sendResponse({tab: sender.tab.id});
    }
    if (msg.text == "what are the open tabs?") {
        let urls = [];
        chrome.tabs.query({}, function(tabs){
            console.log(tabs)
            tabs.map((t) => {
                urls.push(t.url)
            })
            console.log(urls);
            sendResponse({urls: urls});
        });
        return true;
    }
    if (msg.text == "what is my memory?") {
        chrome.system.memory.getInfo(function (m){
            console.log('MEMORY', m);
            sendResponse({memory: m});
        });
        return true;
    }
    if (msg.text == "what is my cpu?") {
        chrome.system.cpu.getInfo(function (c) {
            console.log('CPU', c);
            sendResponse({cpu: c});
        });
        return true;
    }
});

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
        console.log('changeInfo'+JSON.stringify(changeInfo));
        console.log('tab'+tab.url);
        if (changeInfo && changeInfo.status == "complete"  && tab.url) {
            console.log('send message');
            //console.log(JSON.stringify(activeTabs));
            // for (const key in activeTabs) {
            //     console.log(key);
            //     console.log(activeTabs[key]);
            //     if(activeTabs[key]){
            //         let ev = {
            //             name: 'changeUrl',
            //             data: {url: changeInfo.url}
            //         };
            //         chrome.tabs.sendMessage(activeTabs[key].tab.id, ev);
            //     }
            // }
            let ev = {
                name: 'changeUrl',
                data: {url: tab.url}
            };
            chrome.tabs.sendMessage(tab.id, ev);

        }else{
            console.log('no relevent url change');
        }
    }
);

// chrome.tabs.onActivated.addListener(async function(activeInfo) {
//     console.log(activeInfo.tabId);

//     const tabId = activeInfo.tabId;
//     let currentTab = await getTab(tabId);
//     console.log('url : '+currentTab.url);
//     let ev = {
//         name: 'changeUrl',
//         data: {url: currentTab.url}
//     };
//     chrome.tabs.sendMessage(tabId, ev);

// });

getTab = async (tabId)=>{
    return new Promise((resolve, reject) =>{
        chrome.tabs.get(tabId, (tab) =>{
            resolve(tab);
        })
    });
}

// chrome.runtime.onMessage.addListener(function(msg,sender) {
//     // console.log(msg);
//     if(msg.campaignMessageMode){
//         activeTabs[sender.tab.id].campaignMessageMode = true;
//     }
//     // console.log(sender);
// });

// chrome.runtime.onMessage.addListener(function(msg,sender) {
//     if (msg.from == "content") {  //get content scripts tab id
//         contentTabId = sender.tab.id;
//     }
//     if (msg.from == "popup" && contentTabId) {  //got message from popup
//         chrome.tabs.sendMessage(contentTabId, {  //send it to content script
//             from: "background",
//             first: msg.first,
//             second: msg.second
//         });
//     }
// });
